const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
} = require("discord.js");
const config = require("../config.json");
const Login = require("../models/login");

module.exports = {
  name: "login",
  run: async (client, message) => {
    const embed = new EmbedBuilder()
      .setTitle("**نظام دخول العصابات**")
      .setDescription("**اضغط على الزر للدخول أو الخروج**")
    .setImage("https://cdn.discordapp.com/attachments/1204447576640856155/1419744995727900783/IMG_7594.jpg?ex=68d2e010&is=68d18e90&hm=4b4feedd952a25ad269c554d98d1d15e3b3cac9e23f103da8337be18e41b7460&");

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("login_in").setLabel("دخول").setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId("login_out").setLabel("خروج").setStyle(ButtonStyle.Danger)
    );

    const sentMsg = await message.channel.send({ embeds: [embed], components: [row] });
  }
};