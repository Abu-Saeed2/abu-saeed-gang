const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

module.exports = {
  name: "setup-controle",
  run: async (client, message) => {
    const embed = new EmbedBuilder()
      .setTitle("**💻 — لوحة التحكم بالعصابات .**")
      .setDescription("**🏴‍☠️ - يمكنك من الاسفل طرد عضو من عصابتك او رؤية اعضاء العصابة اختر العمليه الذي تريدها .**");

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("kick_control").setLabel("طرد عضو").setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId("members_control").setLabel("الأعضاء").setStyle(ButtonStyle.Secondary)
    );

    message.channel.send({ embeds: [embed], components: [row] });
  }
};