const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  StringSelectMenuBuilder,
} = require("discord.js");
const config = require("../config.json");

module.exports = async (client, interaction) => {
  if (!interaction.isButton() && !interaction.isStringSelectMenu()) return;

  // بداية التحكم في الطرد
  if (interaction.isButton() && interaction.customId === "kick_control") {
    // تحقق هل معه رتبة إداري عصابة
    const isGangAdmin = Object.values(config.gangAdmins).some(adminRoles =>
      adminRoles.some(r => interaction.member.roles.cache.has(r))
    );

    if (!isGangAdmin) {
      return interaction.reply({ content: "ما عندك صلاحية.", ephemeral: true });
    }

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("kick_bloods").setLabel("bloods").setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId("kick_gang187").setLabel("187").setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId("kick_vagos").setLabel("vagos").setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId("kick_scrap").setLabel("scrap").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId("kick_oldschool").setLabel("old school").setStyle(ButtonStyle.Secondary)
    );

    return interaction.reply({ content: "اختر العصابة:", components: [row], ephemeral: true });
  }

  // عند اختيار العصابة من الأزرار
  if (interaction.isButton() && interaction.customId.startsWith("kick_")) {
    const gang = interaction.customId.replace("kick_", "");
    const gangAdmins = config.gangAdmins[gang] || [];

    // تحقق أنه مسؤول العصابة
    if (!gangAdmins.some(r => interaction.member.roles.cache.has(r))) {
      return interaction.reply({ content: "انت مو إداري هذي العصابة.", ephemeral: true });
    }

    const roleId = config.gangRoles[gang];
    const role = interaction.guild.roles.cache.get(roleId);

    if (!role) return interaction.reply({ content: "رتبة العصابة غير موجودة.", ephemeral: true });

    const members = role.members.map(m => ({
      label: m.user.tag,
      value: m.id,
      description: `ID: ${m.id}`,
    }));

    if (members.length === 0) {
      return interaction.reply({
        embeds: [
          new EmbedBuilder().setTitle(`أعضاء ${gang}`).setDescription("الرتبة لا تحتوي على أشخاص حالياً"),
        ],
        ephemeral: true,
      });
    }

    const embed = new EmbedBuilder()
      .setTitle(`أعضاء عصابة ${gang}`)
      .setDescription("اختر العضو المراد طرده")
      .setImage("https://i.imgur.com/8h5mHnS.png"); // تقدر تغير الصورة

    const menu = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId(`kick_member_${gang}`)
        .setPlaceholder("اختر عضو")
        .addOptions(members)
    );

    return interaction.reply({ embeds: [embed], components: [menu], ephemeral: true });
  }

  // لما يختار عضو من القائمة
  if (interaction.isStringSelectMenu() && interaction.customId.startsWith("kick_member_")) {
    const gang = interaction.customId.replace("kick_member_", "");
    const memberId = interaction.values[0];

    const gangAdmins = config.gangAdmins[gang] || [];
    if (!gangAdmins.some(r => interaction.member.roles.cache.has(r))) {
      return interaction.reply({ content: "ما عندك صلاحية.", ephemeral: true });
    }

    const member = await interaction.guild.members.fetch(memberId).catch(() => null);
    if (!member) return interaction.reply({ content: "ما لقيت العضو.", ephemeral: true });

    // إزالة كل الرتب
    for (const role of member.roles.cache.values()) {
      if (role.id !== interaction.guild.id) {
        await member.roles.remove(role.id).catch(() => {});
      }
    }

    // إضافة رتبة الطرد
    await member.roles.add(config.kickRole).catch(() => {});

    return interaction.reply({ content: `تم طرد <@${memberId}> من عصابة ${gang}.`, ephemeral: true });
  }
};