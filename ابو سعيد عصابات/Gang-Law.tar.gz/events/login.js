const {
  EmbedBuilder,
} = require("discord.js");
const config = require("../config.json");
const Login = require("../models/login");

module.exports = async (client, interaction) => {
  if (!interaction.isButton()) return;

  const isLoginButton = interaction.customId === "login_in" || interaction.customId === "login_out";
  if (!isLoginButton) return;

  // تحقق من أنه عنده رتبة عصابة
  const hasGangRole = Object.values(config.gangRoles).some(roleId =>
    interaction.member.roles.cache.has(roleId)
  );
  if (!hasGangRole) {
    return interaction.reply({ content: "لا يمكنك تسجيل الدخول، ليس لديك رتبة عصابة.", ephemeral: true });
  }

  const gangRoles = Object.entries(config.gangRoles).filter(([_, id]) => interaction.member.roles.cache.has(id));
  const gangs = gangRoles.map(([key]) => key);

  // تسجيل الدخول أو الخروج
  const status = interaction.customId === "login_in" ? "in" : "out";

  for (const gang of gangs) {
    await Login.findOneAndUpdate(
      { userId: interaction.user.id, gang },
      { status, lastUpdate: Date.now() },
      { upsert: true }
    );
  }

  // تحديث Embed لجميع أعضاء العصابات
  const embed = new EmbedBuilder().setTitle("__**📋 - حالة الدخول للعصابات**__").setImage("https://cdn.discordapp.com/attachments/1204447576640856155/1419744995727900783/IMG_7594.jpg?ex=68d2e010&is=68d18e90&hm=4b4feedd952a25ad269c554d98d1d15e3b3cac9e23f103da8337be18e41b7460&").setColor("#393939");

  for (const gang of Object.keys(config.gangRoles)) {
    const roleId = config.gangRoles[gang];
    const role = interaction.guild.roles.cache.get(roleId);
    let description = "";

    if (!role || role.members.size === 0) {
      description = "لا يوجد أعضاء";
    } else {
      for (const [id, member] of role.members) {
        const loginData = await Login.findOne({ userId: id, gang });
        const state = loginData && loginData.status === "in" ? "✅ داخل" : "❌ خارج";
        description += `<@${id}> - ${state}\n`;
      }
    }

    embed.addFields({ name: gang, value: description || "لا يوجد أعضاء", inline: false });
  }

  // تحديث الرسالة الأصلية
  await interaction.update({ embeds: [embed], components: interaction.message.components });
};