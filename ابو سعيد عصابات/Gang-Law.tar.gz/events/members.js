const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
} = require("discord.js");
const config = require("../config.json");
const Apply = require("../models/apply");

module.exports = async (client, interaction) => {
  if (!interaction.isButton()) return;

  // بداية التحكم عرض الأعضاء
  if (interaction.customId === "members_control") {
    // تحقق هل معه رتبة إداري عصابة
    const isGangAdmin = Object.values(config.gangAdmins).some(adminRoles =>
      adminRoles.some(r => interaction.member.roles.cache.has(r))
    );

    if (!isGangAdmin) {
      return interaction.reply({ content: "ما عندك صلاحية.", ephemeral: true });
    }

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("members_bloods").setLabel("bloods").setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId("members_gang187").setLabel("187").setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId("members_vagos").setLabel("vagos").setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId("members_scrap").setLabel("scrap").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId("members_oldschool").setLabel("old school").setStyle(ButtonStyle.Secondary)
    );

    return interaction.reply({ content: "اختر العصابة:", components: [row], ephemeral: true });
  }

  // عند اختيار العصابة
  if (interaction.customId.startsWith("members_")) {
    const gang = interaction.customId.replace("members_", "");
    const gangAdmins = config.gangAdmins[gang] || [];

    // تحقق أنه مسؤول العصابة
    if (!gangAdmins.some(r => interaction.member.roles.cache.has(r))) {
      return interaction.reply({ content: "انت مو إداري هذي العصابة.", ephemeral: true });
    }

    const roleId = config.gangRoles[gang];
    const role = interaction.guild.roles.cache.get(roleId);

    if (!role) return interaction.reply({ content: "رتبة العصابة غير موجودة.", ephemeral: true });

    const members = role.members;
    if (members.size === 0) {
      return interaction.reply({
        embeds: [
          new EmbedBuilder().setTitle(`أعضاء ${gang}`).setDescription("لا يوجد احد"),
        ],
        ephemeral: true,
      });
    }

    let desc = "";
    let i = 1;
    for (const [id, member] of members) {
      const data = await Apply.findOne({ userId: id });
      const crimes = data ? data.crimes : "لا يوجد بيانات واضحة";
      desc += `**${i} - العضو : <@${id}>**\n🏴‍☠️ - أعماله الإجرامية: [${crimes}]\n\n`;
      i++;
    }

    const embed = new EmbedBuilder()
      .setTitle(`أعضاء عصابة ${gang}`)
      .setDescription(desc);

    return interaction.reply({ embeds: [embed], ephemeral: true });
  }
};