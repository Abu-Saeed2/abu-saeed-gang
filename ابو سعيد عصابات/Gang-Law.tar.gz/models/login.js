const { Schema, model } = require("mongoose");

const loginSchema = new Schema({
  userId: String,
  gang: String,
  status: { type: String, enum: ["in", "out"], default: "out" },
  lastUpdate: { type: Date, default: Date.now }
});

module.exports = model("Login", loginSchema);