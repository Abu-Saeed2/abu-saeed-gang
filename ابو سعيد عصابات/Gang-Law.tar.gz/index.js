const { Client, GatewayIntentBits, Collection } = require("discord.js");
const fs = require("fs");
const mongoose = require("mongoose");
const config = require("./config.json");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages,
  ],
});

client.commands = new Collection();

// load commands
fs.readdirSync("./command").forEach(file => {
  const cmd = require(`./command/${file}`);
  client.commands.set(cmd.name, cmd);
});

// load events
fs.readdirSync("./events").forEach(file => {
  const event = require(`./events/${file}`);
  client.on("interactionCreate", i => event(client, i));
});

mongoose.connect("داتا بيس", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => console.log("MongoDB connected"));

client.on("messageCreate", async msg => {
  if (!msg.content.startsWith("!")) return;
  const args = msg.content.slice(1).trim().split(/ +/);
  const cmdName = args.shift().toLowerCase();

  if (client.commands.has(cmdName)) {
    client.commands.get(cmdName).run(client, msg, args);
  }
});

client.login(""); //////توكن البوت